export class User{

    Email!:string
    
    Password!:string
    
    }