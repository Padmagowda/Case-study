import React from 'react';
import ReactDOM from 'react-dom';
import { Link, Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import Addtask from './Components/Addtask';
import GetAllTasks from './Components/GetAllTasks';
import Gettaskbyid from './Components/Gettaskbyid';
//import AssignTask from './Components/AssignTask';
import DeleteTask from './Components/DeleteTask';
//import LoginForm from './Components/LoginForm';
import UpdateBookmark from './Components/UpdateBookmark';
import UpdateNotes from './Components/UpdateNotes';
import UpdatePriority from './Components/UpdatePriority';
import Gettaskbypriority from './Components/Gettaskbypriority';

function App() {
  return (
    
    <div >
      <h1 style={{"color":"grey","textAlign":"center","text-shadow":"2px 2px 5px rgb(255, 82, 82)"}}> TASK TRACKING SYSTEM</h1>
      <ul >
       <b>
        <li><Link to="/getalltask">List of Tasks</Link></li>
        <li><Link to="/addtask">Add Task</Link></li>
        <li><Link to="/deletetask">Delete Task</Link></li>
        <li><Link to="/upbookmark">Update Bookmark</Link></li>
        <li><Link to="/uppriority">Update Priority</Link></li>
        <li><Link to="/upnotes">Update Notes</Link></li>
        <li><Link to="/getbyid">Search by TaskId</Link></li>
        
        </b>
      </ul>
     
      <Routes>
        <Route path="/addtask" element={<Addtask/>}></Route>
        <Route path="/getalltask" element={<GetAllTasks/>}></Route>
        <Route path="/getbyid" element={<Gettaskbyid/>}></Route>
        <Route path="/deletetask" element={<DeleteTask/>}></Route>
        <Route path="/upbookmark" element={<UpdateBookmark/>}></Route>
        <Route path="/upnotes" element={<UpdateNotes/>}></Route>
        <Route path="/uppriority" element={<UpdatePriority/>}></Route>
      </Routes>
     

    </div>
    
    
  )
}

ReactDOM.render(

  <Router>
    <App></App>
  </Router>,

  document.getElementById('root')
);