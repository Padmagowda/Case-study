import React from 'react';
import './App.css';

import Addtask from './Components/Addtask';
//import AssignTask from './Components/AssignTask';
import GetAllTasks from './Components/GetAllTasks';
import Gettaskbyid from './Components/Gettaskbyid';
import UpdateBookmark from './Components/UpdateBookmark';
import UpdateNotes from './Components/UpdateNotes';
import UpdatePriority from './Components/UpdatePriority';
import DeleteTask from './Components/DeleteTask';

//import LoginForm from './Components/LoginForm';

function App() {
  return (
    <div>
      
      <Addtask></Addtask>
      <GetAllTasks></GetAllTasks>
      <Gettaskbyid></Gettaskbyid>
      <UpdateBookmark></UpdateBookmark>
     <UpdatePriority></UpdatePriority>
     <UpdateNotes></UpdateNotes>
     <DeleteTask></DeleteTask>
    </div>
  )
}

export default App;