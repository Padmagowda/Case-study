import React,{Component} from "react";
import axios from "axios";

class Addtask extends Component{
    constructor(props){
        super(props)
        this.state={
            task_Id:'',
            owner_Id:'',
            creator_Id:'',
            name:'',
            description:'',
            status:'',
            priority:'',
            notes:'',
            isBookmarked:'',
            created_On:'',
            statusChanged_On:''

        }
        this.changeHandler=this.changeHandler.bind(this)
        this.submitHandler=this.submitHandler.bind(this)
    }
    changeHandler(e){
        this.setState({
            [e.target.name]:e.target.value})
    }
    submitHandler(e){
        e.preventDefault()
        console.log(this.state)
        axios.post('http://localhost:8080/addtask',this.state)
        .then(response=>{
            console.log(response)
        }).catch(error=>{console.log(error)})
    }

    render(){
        const{task_Id,owner_Id,creator_Id,name,description,status,priority,notes,isBookmarked,created_On,statusChanged_On}=this.state
        return(
            <div>
                <div>
                <h2 style={{"color":"black","backgroundColor":"pink","textAlign":"center","opacity":"0.8","margin":"10px 540px 10px"}}>Task Form</h2>
                </div>
                
                <form onSubmit={this.submitHandler} style={{"textAlign":"center","backgroundColor":"#0000ff80","margin":"10px 430px 10px "}}>
                    <div>
                    <b>Task_Id : </b>
                        <input type="number" name="task_Id" value={task_Id} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <div>
                    <b>Owner_Id : </b>
                        <input type="number" name="owner_Id" value={owner_Id} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <div>
                    <b>Creator_Id : </b>
                        <input type="number" name="creator_Id" value={creator_Id} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <div>
                    <b>Task_Name : </b>
                        <input type="string" name="name" value={name} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <div>
                    <b>Description : </b>
                        <input type="string" name="description" value={description} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <div>
                    <b>Status : </b>
                        <select  name="status" value={status} onChange={this.changeHandler}>
                        <option value ="select">select</option>
                        <option value="Close">Close</option>
                        <option value="InProgress">InProgress</option>
                        <option value="Cancelled">Cancelled</option>
                        <option value="OnHold">OnHold</option>
                        
                        </select>

                    </div>
                    <br></br>
                    <div>
                    <b>Priority : </b>
                        <select name="priority" value={priority} onChange={this.changeHandler}>
                        <option value ="select">select</option>
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                        </select>
                    </div>
                    <br></br>
                    <div>
                    <b>Notes : </b>
                        <input type="string" name="notes" value={notes} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <div>
                    <b>IsBookmarked : </b>
                        <select name="isBookmarked" value={isBookmarked} onChange={this.changeHandler}>
                        <option value ="select">select</option>
                        <option value="True">True</option>
                        <option value="False">False</option>
                        </select>
                    </div>
                    <br></br>
                    <div>
                    <b>Created_On : </b>
                        <input type="date" name="created_On" value={created_On} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <div>
                    <b>StatusChanged_On : </b>
                        <input type="datetime-local" name="statusChanged_On" value={statusChanged_On} onChange={this.changeHandler}/>
                    </div>
                    <br></br>
                    <button type="submit" >Submit</button>
                    
                </form>
                
            </div>
        )
    }
    
}

export default Addtask;