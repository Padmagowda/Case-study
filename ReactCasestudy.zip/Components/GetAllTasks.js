import React, { Component } from 'react';
import axios from 'axios';
//import { Route,Link,BrowserRouter as Router, Routes } from "react-router-dom";
//import Gettaskbyid from './Components/Gettaskbyid'



class GetAllTasks extends Component {
    constructor() {
        super()
        this.state = {
            tasks: []
        }
        this.handleClick = this.handleClick.bind(this)
       // this.handleClick1 = this.handleClick1.bind(this)
        //this.handleClick2 = this.handleClick2.bind(this)
        //this.handleClick3 = this.handleClick3.bind(this)
    }
    handleClick() {
        axios.get('http://localhost:8080/listtask')
            .then(response => this.setState({ tasks: response.data }))
    }
   
    render() {
        return (
            <div style={{ "backgroundColor": "#0000ff80", "color": "black", "textAlign": "center","margin":"10px 430px 10px" }}>
                <h2 style={{"color":"black","backgroundColor":"pink","textAlign":"center","opacity":"0.8","margin":"10px 100px 10px"}}>TaskList</h2>
                <button className='button' onClick={this.handleClick}>List of Tasks</button>
                {this.state.tasks.map(task => (
                <h4>
                    Task_ID : {task.task_Id} <br />
                    Owner_ID : {task.owner_Id} <br />
                    Creator_ID : {task.creator_Id} <br />
                    Name : {task.name} <br />
                    Description : {task.description} <br />
                    Status : {task.status} <br />
                    Priority : {task.priority} <br />
                    Notes : {task.notes} <br />
                    IsBookmarked : {task.isBookmarked.toString()} <br />
                    Created_On : {task.created_On} <br />
                    Status_Changed_On : {task.statusChanged_On} <br />
                </h4>))}
                
            </div>
        )
    }
}
export default GetAllTasks;