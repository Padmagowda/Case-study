import React, { Component } from "react";
import axios from "axios";

class Gettaskbyid extends Component {
    constructor() {
        super()
        this.state = {
            Taskname: '', Taskid: '', Priority: '', Status: '', OwnerId: '', isBookmarked: '',Ownerid: '',
            Creatorid: '',Description: '', Notes: '', Createdon: '', Statuschangedon: '', taskID:''
        }
        this.changeHandler=this.changeHandler.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
    }
    changeHandler = (event) => {
        this.setState({[event.target.name]:event.target.value})
    }
    submitHandler = (event) =>  {
        event.preventDefault()
        console.log(this.state)
        axios.get("http://localhost:8080/gettask/"+this.state.taskID,this.state)
            .then(response => this.setState({
                Taskname: response.data.name, Taskid: response.data.task_Id, Creatorid: response.data.creator_Id, Description: response.data.description,
                Priority: response.data.priority, Status: response.data.status, OwnerId: response.data.owner_Id, isBookmarked: response.data.isBookmarked, 
                Createdon: response.data.created_On, Statuschangedon: response.data.statusChanged_On,Notes: response.data.notes
            }))
    }
    
    render() {
        const {taskID} = this.state
        return (
          
            <div style={{"backgroundColor":"#0000ff80","color":"black","textAlign":"center","margin":"10px 100px 10px"}}>
                <h3 style={{"color":"black","backgroundColor":"pink","textAlign":"center","opacity":"0.8","margin":"10px 340px 10px"}}>Search By TaskId</h3><br/>
                  <form  onSubmit={this.submitHandler}>
                <div>
                TaskId : <input type="number" name="taskID" value={taskID} onChange={this.changeHandler} required/>
                </div>
                <button className='button' type="submit">Submit</button>

            </form>
            <br/><br/>
                <table >
                    <thead>
                        <tr style={{"backgroundColor":"grey","alignContent":"center"}}>
                            <th>Task_Id</th>
                            <th>Owner_Id</th>
                            <th>Creator_Id</th>
                            <th>TaskName</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Priority</th>
                            <th>Notes</th>
                            <th>IsBookmarked</th>
                            <th>Created_On</th>
                            <th>StatusChanged_On</th>
                            </tr>
                    </thead>
                    <tbody>
                        <tr if="tasdata">
                            <td>{this.state.Taskid}</td>
                            <td>{this.state.OwnerId}</td>
                            <td>{this.state.Creatorid}</td>
                            <td>{this.state.Taskname}</td>
                            <td>{this.state.Description}</td>
                            <td>{this.state.Status}</td>
                            <td>{this.state.Priority}</td>
                            <td>{this.state.Notes}</td>
                            <td>{this.state.isBookmarked.toString()}</td>
                            <td>{this.state.Createdon}</td>
                            <td>{this.state.Statuschangedon}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }

}
export default Gettaskbyid;